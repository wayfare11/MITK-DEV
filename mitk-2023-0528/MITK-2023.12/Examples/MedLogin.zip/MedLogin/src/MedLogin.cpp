﻿#include "QmitkRegisterClasses.h"
#include "QmitkRenderWindow.h"
#include "QmitkStdMultiWidget.h"
#include "mitkAddContourTool.h"
#include "mitkImage.h"
#include "mitkNodePredicateDataType.h"
#include "mitkProperties.h"
#include "mitkRenderingManager.h"
#include "mitkStandaloneDataStorage.h"
#include "mitkToolManager.h"
#include <QApplication>
#include <QHBoxLayout>
#include <QPushButton>
#include <QVBoxLayout>
#include <itksys/SystemTools.hxx>
#include <mitkDataNode.h>
#include <mitkIOUtil.h>
#include <mitkLabelSet.h>
#include <mitkLabelSetImage.h>
#include <mitkPlanarCircle.h>
#include <mitkPlanarFigureInteractor.h>
#include <mitkPlanarLine.h>
#include <usModuleRegistry.h>

// 槽函数声明
void OnDrawLineButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode);
void OnDrawCircleButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode);
void OnClearDrawingButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode);
void OnAddContourToolButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode);
void OnCreateSegmentationLayerButtonClicked(mitk::StandaloneDataStorage::Pointer ds,
                                            mitk::DataNode::Pointer selectedImageNode);

// 全局变量
int brushSize = 5;
mitk::ToolManager::Pointer toolManager;
mitk::DataNode::Pointer segmentationNode; // 新增分割图层节点

class MyApplication : public QWidget
{
public:
  MyApplication(QWidget *parent = nullptr) : QWidget(parent)
  {
    setFixedSize(2400, 1600); // 设置窗口大小为2400x1600
    SetupWidgets();
  }

private:
  void SetupWidgets()
  {
    // 注册类
    QmitkRegisterClasses();

    // 确保加载 MitkSegmentation 模块
    auto segmentationModule = us::ModuleRegistry::GetModule("MitkSegmentation");
    if (!segmentationModule)
    {
      std::cerr << "MitkSegmentation module not found." << std::endl;
      return;
    }

    // 确保加载 MitkPlanarFigure 模块
    auto planarFigureModule = us::ModuleRegistry::GetModule("MitkPlanarFigure");
    if (!planarFigureModule)
    {
      std::cerr << "MitkPlanarFigure module not found." << std::endl;
      return;
    }

    // 创建顶层数据存储
    mitk::StandaloneDataStorage::Pointer ds = mitk::StandaloneDataStorage::New();

    // 加载图像文件
    const char *filePath = "D:/WorkSpace/DataSet/01_medicaldecathlon/Task06_Lung/imagesTr/lung_001.nii.gz";
    mitk::StandaloneDataStorage::SetOfObjects::Pointer dataNodes = mitk::IOUtil::Load(filePath, *ds);

    if (dataNodes->empty())
    {
      fprintf(stderr, "Could not open file %s \n\n", filePath);
      return;
    }

    // 获取加载的图像节点
    mitk::DataNode::Pointer imageNode = dataNodes->Begin()->Value();

    // 创建顶层布局
    QVBoxLayout *vlayout = new QVBoxLayout(this);
    vlayout->setMargin(0);
    vlayout->setSpacing(2);

    // 创建按钮并添加到布局中
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    QPushButton *drawLineButton = new QPushButton("Draw Line", this);
    buttonLayout->addWidget(drawLineButton);
    QPushButton *drawCircleButton = new QPushButton("Draw Circle", this);
    buttonLayout->addWidget(drawCircleButton);
    QPushButton *clearDrawingButton = new QPushButton("Clear Drawing", this); // 新的清空按钮
    buttonLayout->addWidget(clearDrawingButton);
    QPushButton *addContourToolButton = new QPushButton("Add Contour Tool", this); // 新的添加轮廓工具按钮
    buttonLayout->addWidget(addContourToolButton);
    QPushButton *createSegmentationLayerButton = new QPushButton("Create Segmentation Layer", this); // 新的分割图层按钮
    buttonLayout->addWidget(createSegmentationLayerButton);
    vlayout->addLayout(buttonLayout);

    // 创建视图父窗口和水平布局
    QWidget *viewParent = new QWidget(this);
    vlayout->addWidget(viewParent);
    QHBoxLayout *hlayout = new QHBoxLayout(viewParent);
    hlayout->setMargin(0);

    // 创建和初始化 QmitkStdMultiWidget
    QmitkStdMultiWidget *multiWidget = new QmitkStdMultiWidget(viewParent);
    hlayout->addWidget(multiWidget);

    multiWidget->SetDataStorage(ds);
    multiWidget->InitializeMultiWidget();
    multiWidget->AddPlanesToDataStorage();

    // 初始化工具管理器
    toolManager = mitk::ToolManager::New(ds);
    toolManager->RegisterClient(); // 注册客户端

    // 连接按钮点击事件到槽函数
    QObject::connect(drawLineButton, &QPushButton::clicked, [=]() { OnDrawLineButtonClicked(ds, imageNode); });
    QObject::connect(drawCircleButton, &QPushButton::clicked, [=]() { OnDrawCircleButtonClicked(ds, imageNode); });
    QObject::connect(
      clearDrawingButton, &QPushButton::clicked, [=]() { OnClearDrawingButtonClicked(ds, imageNode); }); // 连接清空按钮
    QObject::connect(addContourToolButton,
                     &QPushButton::clicked,
                     [=]() { OnAddContourToolButtonClicked(ds, imageNode); }); // 连接添加轮廓工具按钮
    QObject::connect(createSegmentationLayerButton,
                     &QPushButton::clicked,
                     [=]() { OnCreateSegmentationLayerButtonClicked(ds, imageNode); }); // 连接创建分割图层按钮

    // 渲染管理器更新
    mitk::RenderingManager::GetInstance()->InitializeViewsByBoundingObjects(ds);
  }
};

int main(int argc, char *argv[])
{
  QApplication qtapplication(argc, argv);

  MyApplication app;
  app.show();

  return qtapplication.exec();
}

// 槽函数实现
void OnDrawLineButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode)
{
  // 创建一个新的PlanarLine对象
  mitk::PlanarLine::Pointer line = mitk::PlanarLine::New();

  // 创建一个新的DataNode并设置其数据为PlanarLine对象
  mitk::DataNode::Pointer lineNode = mitk::DataNode::New();
  lineNode->SetData(line);
  lineNode->SetName("Line");

  // 设置显示属性
  lineNode->SetProperty("planarfigure.default.line.width", mitk::FloatProperty::New(brushSize));
  lineNode->SetProperty("planarfigure.drawcontrolpoints", mitk::BoolProperty::New(true));
  lineNode->SetProperty("planarfigure.drawname", mitk::BoolProperty::New(false)); // 隐藏 "Line" 标签
  lineNode->SetProperty("planarfigure.drawquantities", mitk::BoolProperty::New(true));

  // 将线节点添加到数据存储中
  if (selectedImageNode.IsNotNull())
  {
    mitk::StandaloneDataStorage::SetOfObjects::Pointer parents = mitk::StandaloneDataStorage::SetOfObjects::New();
    parents->InsertElement(0, selectedImageNode);
    ds->Add(lineNode, parents);
  }
  else
  {
    ds->Add(lineNode);
  }

  // 创建并设置交互器
  mitk::PlanarFigureInteractor::Pointer interactor = mitk::PlanarFigureInteractor::New();
  auto planarFigureModule = us::ModuleRegistry::GetModule("MitkPlanarFigure");

  interactor->LoadStateMachine("PlanarFigureInteraction.xml", planarFigureModule);
  interactor->SetEventConfig("PlanarFigureConfig.xml", planarFigureModule);
  interactor->SetDataNode(lineNode);

  // 更新渲染
  mitk::RenderingManager::GetInstance()->RequestUpdateAll();
}

void OnDrawCircleButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode)
{
  // 创建一个新的PlanarCircle对象
  mitk::PlanarCircle::Pointer circle = mitk::PlanarCircle::New();

  // 创建一个新的DataNode并设置其数据为PlanarCircle对象
  mitk::DataNode::Pointer circleNode = mitk::DataNode::New();
  circleNode->SetData(circle);
  circleNode->SetName("Circle");

  // 设置显示属性
  circleNode->SetProperty("planarfigure.default.line.width", mitk::FloatProperty::New(brushSize));
  circleNode->SetProperty("planarfigure.drawcontrolpoints", mitk::BoolProperty::New(true));
  circleNode->SetProperty("planarfigure.drawname", mitk::BoolProperty::New(false));      // 隐藏 "Circle" 标签
  circleNode->SetProperty("planarfigure.drawquantities", mitk::BoolProperty::New(true)); // 显示面积等信息

  // 将圆节点添加到数据存储中
  if (selectedImageNode.IsNotNull())
  {
    mitk::StandaloneDataStorage::SetOfObjects::Pointer parents = mitk::StandaloneDataStorage::SetOfObjects::New();
    parents->InsertElement(0, selectedImageNode);
    ds->Add(circleNode, parents);
  }
  else
  {
    ds->Add(circleNode);
  }

  // 创建并设置交互器
  mitk::PlanarFigureInteractor::Pointer interactor = mitk::PlanarFigureInteractor::New();
  auto planarFigureModule = us::ModuleRegistry::GetModule("MitkPlanarFigure");

  interactor->LoadStateMachine("PlanarFigureInteraction.xml", planarFigureModule);
  interactor->SetEventConfig("PlanarFigureConfig.xml", planarFigureModule);
  interactor->SetDataNode(circleNode);

  // 更新渲染
  mitk::RenderingManager::GetInstance()->RequestUpdateAll();
}

void OnClearDrawingButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode)
{
  // 获取所有PlanarFigure类型的节点
  mitk::StandaloneDataStorage::SetOfObjects::ConstPointer allNodes = ds->GetAll();
  for (auto it = allNodes->Begin(); it != allNodes->End(); ++it)
  {
    mitk::DataNode::Pointer node = it->Value();
    if (dynamic_cast<mitk::PlanarFigure *>(node->GetData()))
    {
      ds->Remove(node);
    }
  }

  // 更新渲染
  mitk::RenderingManager::GetInstance()->RequestUpdateAll();
}

void OnAddContourToolButtonClicked(mitk::StandaloneDataStorage::Pointer ds, mitk::DataNode::Pointer selectedImageNode)
{
  // 确保分割节点已创建
  if (segmentationNode.IsNull())
  {
    std::cerr << "No segmentation layer created. Please create a segmentation layer first." << std::endl;
    return;
  }

  // 确保加载 MitkSegmentation 模块
  auto segmentationModule = us::ModuleRegistry::GetModule("MitkSegmentation");
  if (!segmentationModule)
  {
    std::cerr << "MitkSegmentation module not found." << std::endl;
    return;
  }

  // 获取 AddContourTool 工具的 ID
  int toolID = -1;

  //for (int i = 0; i < toolManager->GetTools().size(); ++i)
  //{
  //  std::cout << toolManager->GetToolById(i)->GetNameOfClass() << endl;
  //}

  for (int i = 0; i < toolManager->GetTools().size(); ++i)
  {
    if (std::string(toolManager->GetToolById(i)->GetNameOfClass()) == "AddContourTool")
    {
      toolID = i;
      break;
    }
  }

  // 激活 AddContourTool 工具
  if (toolID != -1)
  {
    toolManager->SetReferenceData(selectedImageNode); // 设置参考数据为选中的图像节点
    toolManager->SetWorkingData(segmentationNode);    // 设置工作数据为分割图层

    toolManager->ActivateTool(toolID);

    std::cout << "Activated AddContourTool with ID: " << toolID << std::endl;

    // 更新渲染
    mitk::RenderingManager::GetInstance()->RequestUpdateAll();
  }
  else
  {
    std::cerr << "Tool AddContourTool not found." << std::endl;
  }
}

void OnCreateSegmentationLayerButtonClicked(mitk::StandaloneDataStorage::Pointer ds,
                                            mitk::DataNode::Pointer selectedImageNode)
{
  if (selectedImageNode.IsNull())
  {
    std::cerr << "No image selected." << std::endl;
    return;
  }

  // 获取选中图像的数据
  mitk::Image::Pointer image = dynamic_cast<mitk::Image *>(selectedImageNode->GetData());
  if (image.IsNull())
  {
    std::cerr << "Selected node is not an image." << std::endl;
    return;
  }

  // 创建一个新的空白分割图像
  mitk::LabelSetImage::Pointer segmentation = mitk::LabelSetImage::New();
  segmentation->Initialize(image);

  // 创建一个默认标签并添加到分割图像中
  mitk::LabelSet::Pointer labelSet = mitk::LabelSet::New();
  mitk::Label::Pointer label = mitk::Label::New();
  label->SetName("Default");
  mitk::Color color;
  color.SetRed(1.0);
  color.SetGreen(0.0);
  color.SetBlue(0.0);
  label->SetColor(color); // 使用 mitk::Color 设置颜色
  labelSet->AddLabel(label);
  segmentation->AddLabelSetToLayer(0, labelSet);

  // 创建一个新的DataNode并设置其数据为分割图像
  segmentationNode = mitk::DataNode::New();
  segmentationNode->SetData(segmentation);
  segmentationNode->SetName("Segmentation");

  // 设置分割图像的显示属性
  segmentationNode->SetProperty("binary", mitk::BoolProperty::New(true));
  segmentationNode->SetProperty("color", mitk::ColorProperty::New(1.0, 0.0, 0.0)); // 红色
  segmentationNode->SetProperty("name", mitk::StringProperty::New("Segmentation"));

  // 将分割图层节点添加到数据存储中
  mitk::StandaloneDataStorage::SetOfObjects::Pointer parents = mitk::StandaloneDataStorage::SetOfObjects::New();
  parents->InsertElement(0, selectedImageNode);
  ds->Add(segmentationNode, parents);

  // 更新渲染
  mitk::RenderingManager::GetInstance()->RequestUpdateAll();
}